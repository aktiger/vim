###########################################################################
#
# Copyright (c) 2011 Baidu.com, Inc. All Rights Reserved
#
###########################################################################

#Author: <T_AUTHOR> <<T_AUTHOR_EMAIL>>
#<T_AUTHOR_WEBSITE>

#File: <T_FILENAME>
#Create Date: <T_CREATE_DATE>
